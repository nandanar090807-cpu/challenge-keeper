package com.example.challengekeeper.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "challenges")
data class Challenge(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String,
    val targetDateEpochMillis: Long,
    val createdAtEpochMillis: Long = System.currentTimeMillis(),
    val progress: Int = 0,
    val completed: Boolean = false
)