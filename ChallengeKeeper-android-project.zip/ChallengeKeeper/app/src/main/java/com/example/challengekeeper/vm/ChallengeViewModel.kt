package com.example.challengekeeper.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.challengekeeper.data.ChallengeRepository
import com.example.challengekeeper.model.Challenge
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChallengeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ChallengeRepository.get(app)

    val challenges = repo.getAll().stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        emptyList()
    )

    fun upsert(
        id: Long?,
        title: String,
        notes: String,
        targetDateEpochMillis: Long,
        progress: Int,
        completed: Boolean
    ) = viewModelScope.launch {
        val ch = Challenge(
            id = id ?: 0,
            title = title,
            notes = notes,
            targetDateEpochMillis = targetDateEpochMillis,
            progress = progress,
            completed = completed
        )
        if (id == null || id == 0L) repo.add(ch) else repo.update(ch)
    }

    fun delete(ch: Challenge) = viewModelScope.launch { repo.delete(ch) }
}