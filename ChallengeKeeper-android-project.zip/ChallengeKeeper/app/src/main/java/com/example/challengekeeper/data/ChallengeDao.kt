package com.example.challengekeeper.data

import androidx.room.*
import com.example.challengekeeper.model.Challenge
import kotlinx.coroutines.flow.Flow

@Dao
interface ChallengeDao {
    @Query("SELECT * FROM challenges ORDER BY completed ASC, targetDateEpochMillis ASC")
    fun getAll(): Flow<List<Challenge>>

    @Query("SELECT * FROM challenges WHERE id = :id")
    fun getById(id: Long): Flow<Challenge?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(challenge: Challenge): Long

    @Update
    suspend fun update(challenge: Challenge)

    @Delete
    suspend fun delete(challenge: Challenge)
}