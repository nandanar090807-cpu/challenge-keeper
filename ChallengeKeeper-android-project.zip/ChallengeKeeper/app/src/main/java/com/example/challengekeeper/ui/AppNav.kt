package com.example.challengekeeper.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.navArgument
import androidx.navigation.compose.rememberNavController
import com.example.challengekeeper.model.Challenge
import com.example.challengekeeper.vm.ChallengeViewModel
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "list") {
        composable("list") {
            val vm: ChallengeViewModel = viewModel()
            val items by vm.challenges.collectAsState()
            Scaffold(
                topBar = { TopAppBar(title = { Text("ChallengeKeeper") }) },
                floatingActionButton = {
                    FloatingActionButton(onClick = { nav.navigate("edit") }) {
                        Icon(Icons.Default.Add, contentDescription = "Add")
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    if (items.isEmpty()) {
                        EmptyState(onAdd = { nav.navigate("edit") })
                    } else {
                        ChallengeList(
                            items = items,
                            onClick = { nav.navigate("edit?id=${it.id}") }
                        )
                    }
                }
            }
        }
        composable(
            "edit?id={id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType; defaultValue = 0L })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getLong("id") ?: 0L
            val vm: ChallengeViewModel = viewModel()
            EditScreen(id = id, vm = vm, onDone = { nav.popBackStack() })
        }
        composable("edit") {
            val vm: ChallengeViewModel = viewModel()
            EditScreen(id = 0, vm = vm, onDone = { nav.popBackStack() })
        }
    }
}

@Composable
fun EmptyState(onAdd: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No challenges yet")
        Spacer(Modifier.height(8.dp))
        Button(onClick = onAdd) { Text("Add your first challenge") }
    }
}

@Composable
fun ChallengeList(items: List<Challenge>, onClick: (Challenge) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(items) { ch ->
            ElevatedCard(onClick = { onClick(ch) }) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ch.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val daysLeft = daysUntil(ch.targetDateEpochMillis)
                        val dateStr = Instant.ofEpochMilli(ch.targetDateEpochMillis).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                        Text("$dateStr • ${if (daysLeft >= 0) "$daysLeft days left" else "past due"}",
                            style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(
                            progress = { ch.progress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    AssistChip(
                        onClick = {},
                        label = { Text(if (ch.completed) "Done" else "Active") }
                    )
                }
            }
        }
    }
}

private fun daysUntil(epoch: Long): Long {
    val today = LocalDate.now()
    val target = Instant.ofEpochMilli(epoch).atZone(ZoneId.systemDefault()).toLocalDate()
    return java.time.temporal.ChronoUnit.DAYS.between(today, target)
}