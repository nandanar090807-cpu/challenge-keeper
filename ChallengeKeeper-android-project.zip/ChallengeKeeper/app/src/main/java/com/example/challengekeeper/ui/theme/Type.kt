package com.example.challengekeeper.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()