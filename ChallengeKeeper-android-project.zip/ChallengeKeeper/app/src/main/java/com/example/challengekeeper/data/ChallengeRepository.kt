package com.example.challengekeeper.data

import android.content.Context
import com.example.challengekeeper.model.Challenge

class ChallengeRepository(private val dao: ChallengeDao) {
    fun getAll() = dao.getAll()
    fun getById(id: Long) = dao.getById(id)
    suspend fun add(ch: Challenge) = dao.insert(ch)
    suspend fun update(ch: Challenge) = dao.update(ch)
    suspend fun delete(ch: Challenge) = dao.delete(ch)

    companion object {
        @Volatile private var INSTANCE: ChallengeRepository? = null
        fun get(context: Context): ChallengeRepository =
            INSTANCE ?: synchronized(this) {
                val db = AppDatabase.get(context)
                ChallengeRepository(db.challengeDao()).also { INSTANCE = it }
            }
    }
}