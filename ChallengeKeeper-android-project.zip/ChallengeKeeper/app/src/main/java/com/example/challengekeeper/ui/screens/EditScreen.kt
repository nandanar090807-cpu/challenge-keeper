package com.example.challengekeeper.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.challengekeeper.vm.ChallengeViewModel
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.example.challengekeeper.data.ChallengeRepository
import com.example.challengekeeper.model.Challenge
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditScreen(id: Long, vm: ChallengeViewModel, onDone: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { ChallengeRepository.get(context) }
    var title by remember { mutableStateOf(TextFieldValue("")) }
    var notes by remember { mutableStateOf(TextFieldValue("")) }
    var progress by remember { mutableStateOf(0f) }
    var completed by remember { mutableStateOf(false) }
    var targetDateMillis by remember { mutableStateOf(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()) }
    var showDatePicker by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (id != 0L) {
            repo.getById(id).collect { ch ->
                ch?.let {
                    title = TextFieldValue(it.title)
                    notes = TextFieldValue(it.notes)
                    progress = it.progress.toFloat()
                    completed = it.completed
                    targetDateMillis = it.targetDateEpochMillis
                }
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("OK") }
            }
        ) {
            val dateState = rememberDatePickerState(
                initialSelectedDateMillis = targetDateMillis
            )
            DatePicker(
                state = dateState,
                showModeToggle = false
            )
            LaunchedEffect(dateState.selectedDateMillis) {
                dateState.selectedDateMillis?.let { targetDateMillis = it }
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(if (id == 0L) "New Challenge" else "Edit Challenge") }) }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            OutlinedTextField(
                value = title, onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = notes, onValueChange = { notes = it },
                label = { Text("Notes") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 80.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text("Target date: " + Instant.ofEpochMilli(targetDateMillis).atZone(ZoneId.systemDefault()).toLocalDate().toString())
            Spacer(Modifier.height(4.dp))
            Button(onClick = { showDatePicker = true }) { Text("Pick Date") }
            Spacer(Modifier.height(12.dp))
            Text("Progress: ${progress.toInt()}%")
            Slider(value = progress, onValueChange = { progress = it }, valueRange = 0f..100f)
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(checked = completed, onCheckedChange = { completed = it })
                Text("Completed")
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    vm.upsert(
                        id = if (id == 0L) null else id,
                        title = title.text.trim(),
                        notes = notes.text.trim(),
                        targetDateEpochMillis = targetDateMillis,
                        progress = progress.toInt(),
                        completed = completed
                    )
                    onDone()
                }, enabled = title.text.isNotBlank()) {
                    Text("Save")
                }
                if (id != 0L) {
                    val scope = rememberCoroutineScope()
                    OutlinedButton(onClick = {
                        scope.launch {
                            repo.getById(id).first()?.let { vm.delete(it) }
                            onDone()
                        }
                    }) { Text("Delete") }
                }
            }
        }
    }
}