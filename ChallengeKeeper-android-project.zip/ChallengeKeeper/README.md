# ChallengeKeeper
Compose + Material 3 challenge tracker with Room.

## Build (Local)
- Install Android Studio (JDK 17).
- From terminal:
```bash
./gradlew assembleRelease
```
APK will be at `app/build/outputs/apk/release/app-release-unsigned.apk` (sign for distribution).

## Build (GitHub Actions)
Push this repo to GitHub and Actions will attach a downloadable APK artifact.
